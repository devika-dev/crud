<?php 

$con=new mysqli('localhost', 'root', '', 'crudop');

if(!$con)
{
	die(mysqli_error($con));
}
                                 
?>